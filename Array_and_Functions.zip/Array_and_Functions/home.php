<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information Records</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Student Information Records</h1>
        <?php
            // Sample student records
            $student1 = array(
                "firstName" => "Christopher",
                "middleName" => "Mendoza",
                "lastName" => "Jacob",
                "age" => 21,
                "courseYear" => "Information Technology - 2rd Year",
                "enrolled" => true,
                "subjects" => array("OOP-PHP" => 92.1, "Web Standard" => 88.5, "Information Management" => 95.0)
            );

            $student2 = array(
                "firstName" => "John Carlo",
                "middleName" => "G.",
                "lastName" => "Montecastro",
                "age" => 21,
                "courseYear" => "Education - 1st Year",
                "enrolled" => false,
                "subjects" => array("Physics" => 89.7, "Chemistry" => 91.2, "Values" => 94.5)
            );

            $student3 = array(
                "firstName" => "Alice",
                "middleName" => "M.",
                "lastName" => "Johnson",
                "age" => 19,
                "courseYear" => "Business Administration - 1st Year",
                "enrolled" => true,
                "subjects" => array("Economics" => 86.4, "Marketing" => 90.8, "Accounting" => 88.0)
            );

            // Function to display student information
            function displayStudentInfo($student) {
                echo "<div class='student'>";
                echo "<h2>{$student['firstName']} {$student['middleName']} {$student['lastName']}</h2>";
                echo "<p><strong>Age:</strong> {$student['age']}</p>";
                echo "<p><strong>Course and Year:</strong> {$student['courseYear']}</p>";
                echo "<p><strong>Enrolled:</strong> " . ($student['enrolled'] ? 'Yes' : 'No') . "</p>";
                echo "<p><strong>Subjects and Grades:</strong></p>";
                echo "<ul>";
                foreach ($student['subjects'] as $subject => $grade) {
                    echo "<li>{$subject}: {$grade}</li>";
                }
                echo "</ul>";
                echo "</div>";
            }

            // Display student information
            displayStudentInfo($student1);
            displayStudentInfo($student2);
            displayStudentInfo($student3);
        ?>
    </div>
</body>
</html>
